
# coding: utf-8

# In[ ]:

# Here I focused on cleaning the street names and postcode numbers.
# They were misspelled or wrongly inserted in the dataset.


# In[6]:

import xml.etree.cElementTree as ET
from collections import defaultdict
import re
import pprint

OSMFILE = ("lisbon.osm")
street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)
#street_types = defaultdict(set)


expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons", "Rua", "Avenida", "Praca", "Via", "Caminho", "Carreteira",
            "Travessa", "Estrada", "Bairro", "Largo"]

# UPDATE THIS VARIABLE
mapping = { "St": "Street",
            "St.": "Street",
            "Rue": "Rua",
            "Avanida": "Avenida",
            "Estreda": "Estrada",
            "Trav.": "Travessa",
            "Aven.": "Avenida",
            "Camin.": "Caminho",
            "Cal": "Cale",
            "Cale.": "Cale",
            "Rote": "Rota",
            "Vi.": "Via",
            "Via.": "Via",
            "Prac.": "Praca",
            "Carre.": "Carreteira",
            "Av": "Avenida",
            "Av.": "Avenida"      
           
            }

def audit_street_type(street_types, street_name):
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)
            
            

#def print_sorted_dict(d):
#   keys = d.keys()
#   keys = sorted


def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")


def audit(osmfile):
    osm_file = open(osmfile, "r")
    street_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_street_name(tag):
                    audit_street_type(street_types, tag.attrib['v'])
    osm_file.close()
    return street_types


pprint.pprint(dict(audit(OSMFILE))) # let's print the existing names


# In[12]:

def update_name(name, mapping):
    name = name.split(' ')
    for i in range(len(name)):
        if name[i] in mapping:
            name[i] = mapping[name[i]]
        name = ' '.join(name)
        return name


def test():
    street_types = audit(OSMFILE)
    pprint.pprint(dict(street_types))

    for street_type, ways in street_types.iteritems():
        for name in ways:
            better_name = update_name(name, mapping)
            print name, "=>", better_name
        


if __name__ == '__main__':
    test()
    
    update_street = audit(OSMFILE) 

# let's print the updated names
for street_type, ways in update_street.iteritems():
    for name in ways:
        better_name = update_name(name, mapping)
        print name, "=>", better_name  
        
#print update_street


# In[7]:

# Now, we can start the process of auditing the postcodes for the city of Lisbon:
# The typical code in Portugal should look like this: 1000-260 Lisboa (https://en.wikipedia.org/wiki/Postal_codes_in_Portugal)
# Contains 4 digits, "-", and 3 digits 


# In[8]:

# Let's find tags which k atrtibute includes postcodes and then print them all:

def audit_pc(filename): 
    postcode = set() 
    for _ , element in ET.iterparse(filename): 
        if element.tag =="tag": 
            if element.attrib.get('k') == 'addr:postcode':
                 postcode.add(element.attrib["v"])

    return postcode

postcode = audit_pc('lisbon.osm')
pprint.pprint(postcode)


# In[9]:

for post in postcode:
    print post


# In[10]:

# Now we can clean them by checking if the containt the required pattern and correct it if not:

POSTCODE = re.compile("00[679]\d{2}([ \-]\d{4})?")


def postcode_clean(postcode):
    m = POSTCODE.search(postcode)
    if m:
        if "-" not in postcode:
            postcode = postcode[:4] + " " + postcode[3:]
    
        return postcode
    else:
    
        if postcode != POSTCODE:
            return postcode  


# In[11]:

cleaned_postcodes = []

for post in postcode:
    cleaned_postcodes.append(postcode_clean(post))

for post in cleaned_postcodes:
    print post


# In[ ]:



