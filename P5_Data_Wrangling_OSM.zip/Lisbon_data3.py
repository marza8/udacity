
# coding: utf-8

# In[1]:

# This is a data for the city of lisbon. Most of the code below was provided by Udacity.


# In[1]:

# Creating a sample:

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET  # Use cElementTree or lxml if too slow

OSM_FILE = "lisbon.osm"  # Replace this with your osm file
SAMPLE_FILE = "sample.osm"

k = 10 # Parameter: take every k-th top level element

def get_element(osm_file, tags=('node', 'way', 'relation')):
    """Yield element if it is the right type of tag

    Reference:
    http://stackoverflow.com/questions/3095434/inserting-newlines-in-xml-file-generated-via-xml-etree-elementtree-in-python
    """
    context = iter(ET.iterparse(osm_file, events=('start', 'end')))
    _, root = next(context)
    for event, elem in context:
        if event == 'end' and elem.tag in tags:
            yield elem
            root.clear()


with open(SAMPLE_FILE, 'wb') as output:
    output.write('<?xml version="1.0" encoding="UTF-8"?>\n')
    output.write('<osm>\n  ')

    # Write every kth top level element
    for i, element in enumerate(get_element(OSM_FILE)):
        if i % k == 0:
            output.write(ET.tostring(element, encoding='utf-8'))

    output.write('</osm>')


# In[3]:

import csv
import codecs
import pprint
import re
import xml.etree.cElementTree as ET

import cerberus

import schema

from Lisbon_Audit import update_name, mapping,  postcode_clean

OSM_PATH = "lisbon.osm"

NODES_PATH = "nodes.csv"
NODE_TAGS_PATH = "nodes_tags.csv"
WAYS_PATH = "ways.csv"
WAY_NODES_PATH = "ways_nodes.csv"
WAY_TAGS_PATH = "ways_tags.csv"


# UPDATE THIS VARIABLE
mapping = { "St": "Street",
            "St.": "Street",
            "Rue": "Rua",
            "Avanida": "Avenida",
            "Estreda": "Estrada",
            "Trav.": "Travessa",
            "Aven.": "Avenida",
            "Camin.": "Caminho",
            "Cal": "Cale",
            "Cale.": "Cale",
            "Rote": "Rota",
            "Vi.": "Via",
            "Via.": "Via",
            "Prac.": "Praca",
            "Carre.": "Carreteira",
            "Av": "Avenida",
            "Av.": "Avenida"      
           
            }


LOWER_COLON = re.compile(r'^([a-z]|_)+:([a-z]|_)+')
PROBLEMCHARS = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')

SCHEMA = schema.schema

# Make sure the fields order in the csvs matches the column order in the sql table schema
NODE_FIELDS = ['id', 'lat', 'lon', 'user', 'uid', 'version', 'changeset', 'timestamp']
NODE_TAGS_FIELDS = ['id', 'key', 'value', 'type']
WAY_FIELDS = ['id', 'user', 'uid', 'version', 'changeset', 'timestamp']
WAY_TAGS_FIELDS = ['id', 'key', 'value', 'type']
WAY_NODES_FIELDS = ['id', 'node_id', 'position']

expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons", "Rua", "Avenida", "Praca", "Via", "Caminho", "Carreteira",
            "Travessa", "Estrada", "Bairro", "Largo"]


#def print_sorted_dict(d):
#   keys = d.keys()
#   keys = sorted


def update_name(name, mapping):
    name = name.split(' ')
    for i in range(len(name)):
        if name[i] in mapping:
            name[i] = mapping[name[i]]
        name = ' '.join(name)
        return name
    
#def update_name(name, mapping):
#   m  = street_type_re.search(name)  # like this I check the street names pattern
#  if m.group() :  # here I extract the word 
#     wrong_word  = m.group()
#    if wrong_word in mapping.keys():
#       name = re.sub(street_type_re, mapping[wrong_word], name)
#return name

POSTCODE = re.compile("00[679]\d{2}([ \-]\d{4})?")


def postcode_clean(postcode):
    m = POSTCODE.search(postcode)
    if m:
        if "-" not in postcode:
            postcode = postcode[:4] + " " + postcode[3:]
    
        return postcode
    else:
    
        if postcode != POSTCODE:
            return postcode  

def shape_element(element, node_attr_fields=NODE_FIELDS, way_attr_fields=WAY_FIELDS,
                  problem_chars=PROBLEMCHARS, default_tag_type='regular'):
    """Clean and shape node or way XML element to Python dict"""

    node_attribs = {}
    way_attribs = {}
    way_nodes = []
    tags = []  # Handle secondary tags the same way for both node and way elements

    # YOUR CODE HERE, here we create the CSV files, so later we can query them in SQL
    if element.tag == 'node':
        for attrib in element.attrib:
            if attrib in NODE_FIELDS:
                node_attribs[attrib] = element.attrib[attrib]
        
        for child in element:
            node_tag = {}
            if LOWER_COLON.match(child.attrib['k']):
                node_tag['type'] = child.attrib['k'].split(':',1)[0]
                node_tag['key'] = child.attrib['k'].split(':',1)[1]
                node_tag['id'] = element.attrib['id']
                node_tag['value'] = child.attrib['v'] 
                if child.attrib['k'] == 'addr:street':
                    node_tag['value'] = update_name(child.attrib['v'],mapping)
                elif child.attrib["k"] == 'addr:postcode':
                    node_tag["value"] = postcode_clean(child.attrib["v"])
                tags.append(node_tag)
                
            elif PROBLEMCHARS.match(child.attrib['k']):
                continue
            else:
                node_tag['type'] = 'regular'
                node_tag['key'] = child.attrib['k']
                node_tag['id'] = element.attrib['id']
                node_tag['value'] = child.attrib['v']
                tags.append(node_tag)
        
        return {'node': node_attribs, 'node_tags': tags}
        
    elif element.tag == 'way':
        for attrib in element.attrib:
            if attrib in WAY_FIELDS:
                way_attribs[attrib] = element.attrib[attrib]
        
        position = 0
        for child in element:
            way_tag = {}
            way_node = {}
            
            if child.tag == 'tag':
                if LOWER_COLON.match(child.attrib['k']):
                    way_tag['type'] = child.attrib['k'].split(':',1)[0]
                    way_tag['key'] = child.attrib['k'].split(':',1)[1]
                    way_tag['id'] = element.attrib['id']
                    way_tag['value'] = child.attrib['v']                   
                    if child.attrib['k'] == 'addr:street':
                        way_tag["value"]  = update_name(child.attrib["v"],mapping)
                    elif child.attrib["k"] == 'addr:postcode':
                        way_tag["value"] = postcode_clean(child.attrib["v"])
                    tags.append(way_tag)
                elif PROBLEMCHARS.match(child.attrib['k']):
                    continue
                else:
                    way_tag['type'] = 'regular'
                    way_tag['key'] = child.attrib['k']
                    way_tag['id'] = element.attrib['id']
                    way_tag['value'] = child.attrib['v']
                    tags.append(way_tag)
                    
            elif child.tag == 'nd':
                way_node['id'] = element.attrib['id']
                way_node['node_id'] = child.attrib['ref']
                way_node['position'] = position
                position += 1
                way_nodes.append(way_node)
            
        
        return {'way': way_attribs, 'way_nodes': way_nodes, 'way_tags': tags}


# In[4]:

# ================================================== #
#               Helper Functions                     #
# ================================================== #
def get_element(osm_file, tags=('node', 'way', 'relation')):
    """Yield element if it is the right type of tag"""

    context = ET.iterparse(osm_file, events=('start', 'end'))
    _, root = next(context)
    for event, elem in context:
        if event == 'end' and elem.tag in tags:
            yield elem
            root.clear()


# In[5]:

# ================================================== #
#               Helper Functions                     #
# ================================================== #
def validate_element(element, validator, schema=SCHEMA):
    """Raise ValidationError if element does not match schema"""
    if validator.validate(element, schema) is not True:
        field, errors = next(validator.errors.iteritems())
        message_string = "\nElement of type '{0}' has the following errors:\n{1}"
        error_string = pprint.pformat(errors)
        
        raise Exception(message_string.format(field, error_string))


# In[45]:

# ================================================== #
#               Helper Functions                     #
# ================================================== #
class UnicodeDictWriter(csv.DictWriter, object):
    """Extend csv.DictWriter to handle Unicode input"""

    def writerow(self, row):
        super(UnicodeDictWriter, self).writerow({
            k: (v.encode('utf-8') if isinstance(v, unicode) else v) for k, v in row.iteritems()
        })

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)


# In[46]:


# ================================================== #
#               Main Function                        #
# ================================================== #
def process_map(file_in, validate):
    """Iteratively process each XML element and write to csv(s)"""

    with codecs.open(NODES_PATH, 'w') as nodes_file,          codecs.open(NODE_TAGS_PATH, 'w') as nodes_tags_file,          codecs.open(WAYS_PATH, 'w') as ways_file,          codecs.open(WAY_NODES_PATH, 'w') as way_nodes_file,          codecs.open(WAY_TAGS_PATH, 'w') as way_tags_file:

        nodes_writer = UnicodeDictWriter(nodes_file, NODE_FIELDS)
        node_tags_writer = UnicodeDictWriter(nodes_tags_file, NODE_TAGS_FIELDS)
        ways_writer = UnicodeDictWriter(ways_file, WAY_FIELDS)
        way_nodes_writer = UnicodeDictWriter(way_nodes_file, WAY_NODES_FIELDS)
        way_tags_writer = UnicodeDictWriter(way_tags_file, WAY_TAGS_FIELDS)

        nodes_writer.writeheader()
        node_tags_writer.writeheader()
        ways_writer.writeheader()
        way_nodes_writer.writeheader()
        way_tags_writer.writeheader()

        validator = cerberus.Validator()

        for element in get_element(file_in, tags=('node', 'way')):
            el = shape_element(element)
            if el:
                if validate is True:
                    validate_element(el, validator)

                if element.tag == 'node':
                    nodes_writer.writerow(el['node'])
                    node_tags_writer.writerows(el['node_tags'])
                elif element.tag == 'way':
                    ways_writer.writerow(el['way'])
                    way_nodes_writer.writerows(el['way_nodes'])
                    way_tags_writer.writerows(el['way_tags'])


if __name__ == '__main__':
    # Note: Validation is ~ 10X slower. For the project consider using a small
    # sample of the map when validating.
    process_map(OSM_PATH, validate=False)


# In[47]:

# quiz iterative parsing
import xml.etree.cElementTree as ET
import pprint
from collections import defaultdict

def count_tags(filename):
    tags = defaultdict(int)
    tree = ET.parse(filename)
    root = tree.getroot()
    for element in root.iter():
        tags[element.tag] += 1
    return tags


# In[48]:

def test():

    tags = count_tags('lisbon.osm')
    pprint.pprint(tags)

    
    

if __name__ == "__main__":
    test()


# In[49]:

#!/usr/bin/env python   quiz tag types

import xml.etree.cElementTree as ET
import pprint
import re
"""
Your task is to explore the data a bit more.
Before you process the data and add it into your database, you should check the
"k" value for each "<tag>" and see if there are any potential problems.

We have provided you with 3 regular expressions to check for certain patterns
in the tags. As we saw in the quiz earlier, we would like to change the data
model and expand the "addr:street" type of keys to a dictionary like this:
{"address": {"street": "Some value"}}
So, we have to see if we have such tags, and if we have any tags with
problematic characters.

Please complete the function 'key_type', such that we have a count of each of
four tag categories in a dictionary:
  "lower", for tags that contain only lowercase letters and are valid,
  "lower_colon", for otherwise valid tags with a colon in their names,
  "problemchars", for tags with problematic characters, and
  "other", for other tags that do not fall into the other three categories.
See the 'process_map' and 'test' functions for examples of the expected format.
"""


lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')


def key_type(element, keys):
    if element.tag == "tag":
        att = element.attrib['k'] 
        m = lower.search(att)
        o = problemchars.search(att)
        n = lower_colon.search(att)
        
        if m:
          
            keys["lower"]+=1
        elif n:
                 keys["lower_colon"] += 1
        elif o:
                 keys["problemchars"] += 1
        else:
                 keys["other"] += 1 
        
        
        
    return keys



def process_map(filename):
    keys = {"lower": 0, "lower_colon": 0, "problemchars": 0, "other": 0}
    for _, element in ET.iterparse(filename):
        keys = key_type(element, keys)

    return keys



def test():
    # You can use another testfile 'map.osm' to look at your solution
    # Note as well that the test function here is only used in the Test Run;
    # when you submit, your code will be checked against a different dataset.
    keys = process_map('lisbon.osm')
    pprint.pprint(keys)



if __name__ == "__main__":
    test()


# In[50]:

def count_tags(filename):
    tags = defaultdict(int)
    tree = ET.parse(filename)
    root = tree.getroot()
    for element in root.iter():
        tags[element.tag] += 1
    return tags

def test():

    tags = count_tags('sample.osm')
    pprint.pprint(tags)
   
    

if __name__ == "__main__":
    test()


# In[51]:

lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')


def key_type(element, keys):
    if element.tag == "tag":
        att = element.attrib['k'] 
        m = lower.search(att)
        o = problemchars.search(att)
        n = lower_colon.search(att)
        
        if m:
          
            keys["lower"]+=1
        elif n:
                 keys["lower_colon"] += 1
        elif o:
                 keys["problemchars"] += 1
        else:
                 keys["other"] += 1 
        
        
        
    return keys



def process_map(filename):
    keys = {"lower": 0, "lower_colon": 0, "problemchars": 0, "other": 0}
    for _, element in ET.iterparse(filename):
        keys = key_type(element, keys)

    return keys



def test():
    # You can use another testfile 'map.osm' to look at your solution
    # Note that the assertion below will be incorrect then.
    # Note as well that the test function here is only used in the Test Run;
    # when you submit, your code will be checked against a different dataset.
    keys = process_map('sample.osm')
    pprint.pprint(keys)



if __name__ == "__main__":
    test()


# In[52]:

def parse_file1(datafile):
    data_1 = []
    with open(datafile,"rb") as f:
        reader = unicodecsv.DictReader(f)
        data_1 = list(reader)
        
    return data_1


#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.cElementTree as ET
import pprint
import re
"""
Your task is to explore the data a bit more.
The first task is a fun one - find out how many unique users
have contributed to the map in this particular area!

The function process_map should return a set of unique user IDs ("uid")
"""

def get_user(element):
    return


def process_map(filename):
    users = set()
    for _, element in ET.iterparse(filename):
        if element.tag =="node" or element.tag =="way" or element.tag =="relation":
            if element.attrib.get('uid'):
                users.add(element.attrib["uid"])
            
        
        pass

    return users


def test():

    users = process_map('sample.osm')
    pprint.pprint(users)
    print len(users)


if __name__ == "__main__":
    test()


# In[53]:

# We can see that 739 users contributed to the OSM of Lisbon in my sample. What is quite a lot.


# In[54]:

import xml.etree.cElementTree as ET
from collections import defaultdict
import re
import pprint

OSMFILE = "lisbon.osm"
street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)


expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons", "Rua", "Avenida", "Praca", "Via", "Caminho", "Carreteira",
            "Travessa", "Estrada", "Bairro", "Largo"]

# UPDATE THIS VARIABLE
mapping = { "St": "Street",
            "St.": "Street",
            "Rue": "Rua",
            "Avanida": "Avenida",
            "Estreda": "Estrada",
            "Trav.": "Travessa",
            "Aven.": "Avenida",
            "Camin.": "Caminho",
            "Cal": "Cale",
            "Cale.": "Cale",
            "Rote": "Rota",
            "Vi.": "Via",
            "Via.": "Via",
            "Prac.": "Praca",
            "Carre.": "Carreteira",
            "Av": "Avenida",
            "Av.": "Avenida"      
           
            }

def audit_street_type(street_types, street_name):
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)


def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")


def audit(osmfile):
    osm_file = open(osmfile, "r")
    street_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_street_name(tag):
                    audit_street_type(street_types, tag.attrib['v'])
    osm_file.close()
    return street_types


pprint.pprint(dict(audit(OSMFILE))) # let's print the existing names


# In[55]:

#def update_name(name, mapping):
#    m  = street_type_re.search(name)  # like this I check the street names pattern
#    if m.group() :  # here I extract the word 
#        wrong_word  = m.group()
#        if wrong_word in mapping.keys():
#            name = re.sub(street_type_re, mapping[wrong_word], name)
#            
#    return name

def update_name(name, mapping):
    name = name.split(' ')
    for i in range(len(name)):
        if name[i] in mapping:
            name[i] = mapping[name[i]]
        name = ' '.join(name)
        return name

def test():
    street_types = audit(OSMFILE)
    pprint.pprint(dict(street_types))

    for street_type, ways in street_types.iteritems():
        for name in ways:
            better_name = update_name(name, mapping)
            print name, "=>", better_name
        


if __name__ == '__main__':
    test()
    
update_street = audit(OSMFILE) 

# let's print the updated names
for street_type, ways in update_street.iteritems():
    for name in ways:
        better_name = update_name(name, mapping)
        print name, "=>", better_name  
        
print update_street


# In[ ]:



