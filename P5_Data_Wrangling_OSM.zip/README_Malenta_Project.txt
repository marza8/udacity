Please find here a few explenation to my Project:

1) The PDF (database_again_lisbon, provided also in md) file contains:
	- Area of Investigation
	- Creating the database:
	(followed instructions of Myles on the forum)
	- Overview of the data
	- Ideas of Improvement

2) The Lisbon_Audit.ipynb file contains:
	- Simple audit of the sample:
	  streetname and postcode

3) The Lisbon_data.ipynb file contains:
	- the process of creating a sample file,
	  provided by Udacity
	- functions from Udacity Case Study

4) Resources Text File

