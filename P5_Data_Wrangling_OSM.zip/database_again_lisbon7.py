
# coding: utf-8

# ###        Area of Investigation:
#  
# For my third Udacity project I chose to investigate a dataset for a beautiful city of Lisbon. I downloaded from *Mapzen*
# metro extract, which you can find here: https://mapzen.com/data/metro-extracts/your-extracts/8df9ee595872
# 
# I used to live near Lisbon as a polish immigrant and was always amazed by its charm. 
# As one of the oldest cities in Europe has outrages amounts of attractions for visitors and citizens. 
# Let's see what I'm gonna discover by wrangling this Open Street Map dataset using Python and SQL.
# 
# 
# Problems encountred in tha map:
# 
# After downloading the file and running it locally in the prompt I found a few problems:
# 
# 1. *Street names were messy, many misspellings and not with not finished names.*
#         '1974': set(['Av. 25 De Abril 1974']),
# 2. *Postcodes are incomplete or not valid*
#         '1000',
# It was cleaned already with Python in the audit file.
# 

# *Let's see the wrong streetnames changed after correction:*
# 
# * Av. Mal. Craveiro Lopes => Avenida Mal. Craveiro Lopes
# * Av. Fontes Pereira de Melo => Avenida Fontes Pereira de Melo
# * Av. 25 De Abril 1974 => Avenida 25 De Abril 1974
# * Av. D. João II - Parcela 1.14 Lote 3 => Avenida D. João II - Parcela 1.14 Lote 3
# * Av. Campo Grande => Avenida Campo Grande
# * Av. Sérgio Vieira de Mello => Avenida Sérgio Vieira de Mello
# * Av. Mal. Craveiro Lopes => Avenida Mal. Craveiro Lopes
# * Av Rio de Janeiro Mercado alvalade Norte loja 52 Lisboa => Avenida Rio de Janeiro Mercado alvalade Norte loja 52 Lisboa

# While **cleaning the street name issues** I used the update_name function, which iterates over every word in the the address street 
# and then turns it to the proper version created in the mapping of the Lisbon_audit.py file.
# 

# In[ ]:

def update_name(name, mapping):
    name = name.split(' ')
    for i in range(len(name)):
        if name[i] in mapping:
            name[i] = mapping[name[i]]
        name = ' '.join(name)
        return name


# **Postal codes** 
# Some of them very empty or just half-empty 
# Thanks to using a simple statement for the proper postcode design:  *postcode = postcode[:4] + " " + postcode[3:]*
# which basically contains 4 digits, "-", and 3 digits we go through all the postcodes and check the format.
# After that we can change the wrong formats by executing **postcode_clean function**

# *Dirty postcodes looked like this:*
# * 1169 - 199 
# * 1675_266 
# * 1500 - 327
# * 1150 - 023 
# * 2800 - 057 

# In[1]:

def postcode_clean(postcode):
    m = POSTCODE.search(postcode)
    if m:
        if "-" not in postcode:
            postcode = postcode[:4] + " " + postcode[3:]
    
        return postcode
    else:
    
        if postcode != POSTCODE:
            return postcode


# *After cleaning:*
# * 1169-199
# * 1675-266
# * 1500-237
# * 1150-023
# * 2800-057 

# #### Creating a database for queries:
# I followed the instructions provided on Udacity's forum by Myles. 
# Database contents 5 csv files like: *nodes, ways, ways_nodes, ways_tags, nodes_tags.*
# Creating the first table is described below with comments, creating the rest is practically the same. 
# 

# In[1]:

import sqlite3
import csv
from pprint import pprint

sqlite_file = 'lisbon.db'    # my sqlite database file

# Connect to the database:
conn = sqlite3.connect(sqlite_file)
conn.text_factory = str

cur = conn.cursor()

# create the nodes_tags table 
cur.execute('''DROP TABLE IF EXISTS nodes_tags''')
conn.commit()

cur.execute('''
    CREATE TABLE nodes_tags(id INTEGER, key TEXT, value TEXT,type TEXT)
''')

conn.commit()

with open('nodes_tags.csv','rb') as fin:
    dr = csv.DictReader(fin) # comma is default delimiter
    to_db = [(i['id'], i['key'],i['value'], i['type']) for i in dr]
   
    
cur.executemany("INSERT INTO nodes_tags(id, key, value, type) VALUES (?, ?, ?, ?);", to_db)

conn.commit()

# create the nodes table:
cur.execute('''DROP TABLE IF EXISTS nodes''')
conn.commit()

cur.execute('''
    CREATE TABLE nodes(id INTEGER, lat INTEGER, lon INTEGER, user KEY, uid INGETER, version INTEGER, changeset TEXT, timestamp TEXT)
''')
conn.commit()

with open('nodes.csv','rb') as fin:
    dr = csv.DictReader(fin)
    to_db = [(i["id"], i['lat'], i['lon'], i['user'], i['uid'], i["version"], i["changeset"], i["timestamp"]) for i in dr]
   
cur.executemany("INSERT INTO nodes(id, lat, lon, user, uid, version, changeset, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?);", to_db)
conn.commit()


# create the ways_tags table:
cur.execute('''DROP TABLE IF EXISTS ways_tags''')
conn.commit()

cur.execute('''
    CREATE TABLE ways_tags(id INTEGER, key TEXT, value TEXT, type TEXT)
''')
conn.commit()

with open('ways_tags.csv','rb') as fin:
    dr = csv.DictReader(fin) 
    to_db = [(i['id'], i['key'],i['value'], i['type']) for i in dr]
   
cur.executemany("INSERT INTO ways_tags(id, key, value, type) VALUES (?, ?, ?, ?);", to_db)
conn.commit()


# create the ways table:
cur.execute('''DROP TABLE IF EXISTS ways''')
conn.commit()

cur.execute('''
    CREATE TABLE ways(id INTEGER, user KEY, uid INTEGER, version INTEGER, changeset TEXT, timestamp TEXT)
''')
conn.commit()


with open('ways.csv','rb') as fin:
    dr = csv.DictReader(fin) 
    to_db = [(i['id'], i['user'], i['uid'], i['version'], i['changeset'], i['timestamp'] ) for i in dr]
   
    
cur.executemany("INSERT INTO ways(id, user, uid, version, changeset, timestamp) VALUES (?, ?, ?, ?, ?, ?);", to_db)
conn.commit()


# create the ways_nodes table:
cur.execute('''DROP TABLE IF EXISTS ways_nodes''')
conn.commit()

cur.execute('''
    CREATE TABLE ways_nodes(id INTEGER, node_id INTEGER, position INTEGER)
''')
conn.commit()
with open('ways_nodes.csv','rb') as fin:
    dr = csv.DictReader(fin) 
    to_db = [(i['id'], i['node_id'],i['position']) for i in dr]
   
cur.executemany("INSERT INTO ways_nodes(id, node_id, position) VALUES (?, ?, ?);", to_db)
conn.commit()


# Fast check if the database is properly created. Let's run a simple query on each table:

# In[2]:

cur.execute("SELECT * FROM nodes limit 2")
all_rows = cur.fetchall()
print('1):')
print (all_rows)


# In[ ]:

cur.execute('SELECT e.user, COUNT(*) as num FROM (SELECT user FROM nodes UNION ALL SELECT user FROM ways) e GROUP BY e.user ORDER BY num DESC LIMIT 15')
all_rows = cur.fetchall()
pprint(all_rows)


# In[3]:

cur.execute('SELECT * FROM ways_tags limit 2')
all_rows = cur.fetchall()
print('1):')
pprint(all_rows)


# In[4]:

cur.execute('SELECT * FROM ways limit 2')
all_rows = cur.fetchall()
print('1):')
pprint(all_rows)


# In[5]:

cur.execute('SELECT * FROM nodes_tags limit 2')
all_rows = cur.fetchall()
print('1):')
pprint(all_rows)


# In[6]:

cur.execute('SELECT * FROM nodes_tags limit 2')
all_rows = cur.fetchall()
print('1):')
pprint(all_rows)


# ### Overview of the data:

# In[33]:

# First, let's check my data file sizes:

from pprint import pprint
import os
from hurry.filesize import size

dirpath = 'C:\Users\Marcela\Desktop\Udacity\OpenStreetMap\PROJECT'

file_size_wanted = ['nodes.csv','nodes_tags.csv','lisbon.osm','database_again_lisbon.sqlite', 'ways.csv','ways_nodes.csv','ways_tags.csv']

files_list = []
for path, dirs, files in os.walk(dirpath):
    files_list.extend([(filename, size(os.path.getsize(os.path.join(path, filename)))) for filename in files])

for filename, size in files_list:
    if filename in file_size_wanted :
        print '{:.<40s}: {:5s}'.format(filename,size)


# In[36]:

# Verifing the number of users, as we see 3278312, that's quite a lot:
cur.execute('SELECT uid, COUNT(*) as num FROM (SELECT uid FROM nodes UNION ALL SELECT uid FROM ways)')
all_rows = cur.fetchall()
pprint(all_rows)


# In[22]:

# Checking the number of ways, 76311 in the output:
cur.execute('SELECT COUNT(*) FROM ways')
all_rows = cur.fetchall()
pprint(all_rows)


# In[23]:

# Checking the number of nodes, 381200 in the output:
cur.execute('SELECT COUNT(*) FROM nodes')
all_rows = cur.fetchall()
pprint(all_rows)


# In[16]:

# 1880 shops are recorded in this database:
cur.execute('SELECT key, COUNT(*) as num FROM (SELECT key FROM nodes_tags UNION ALL SELECT key FROM ways_tags) WHERE key="shop" ORDER BY num DESC')
all_rows = cur.fetchall()
pprint(all_rows)


# In[10]:

# Let's check the most contruibuting users for Lisbon. Apparently, Josef K put a lot of effort to this data! 
# The difference between the first biggest contriubutor and the second is huge. Second was !i! with 40711 
# and third - Oha with 40711.
cur.execute('SELECT e.user, COUNT(*) as num FROM (SELECT user FROM nodes UNION ALL SELECT user FROM ways) e GROUP BY e.user ORDER BY num DESC LIMIT 15')
all_rows = cur.fetchall()
pprint(all_rows)


# In[8]:

cur.execute('SELECT * FROM ways WHERE user="Josef K" limit 5')
all_rows = cur.fetchall()
pprint(all_rows)


# In[20]:

# Let' see if there are leisure activities in Lisbon and what kind of:
cur.execute('SELECT * FROM nodes_tags WHERE key="leisure" limit 15')
all_rows = cur.fetchall()
pprint(all_rows)


# In[40]:

# 1322 lesiures are found, let's take a look a bit closer to it.
cur.execute('SELECT COUNT (*) FROM (SELECT key FROM nodes_tags UNION ALL SELECT key FROM ways_tags) WHERE key="leisure"')
all_rows = cur.fetchall()
pprint(all_rows)


# In[19]:

# I want to see what type of leisures is the most popular in Lisbon. And here it is, the country of Christiano Ronaldo
# have many playgrounds - 63, only 26 sports centres.
cur.execute('SELECT value, COUNT(*) as num FROM nodes_tags WHERE key="leisure" GROUP BY value ORDER BY num DESC limit 8')
all_rows = cur.fetchall()
pprint(all_rows)


# ## Other ideas about the dataset:
# 
# 
#  While wrangling this data I came up with a few ideas of improvement.
#  We could add more tourists attractions and encourage users to focus on this aspects of data.
#  Let's think about **Gamification** - it is the process of taking something that already exists – a website, 
#  an enterprise application, an online community – and integrating game mechanics into it to motivate 
#  participation, engagement, and loyalty. If all the other users could know that only of them is providing most of the data to
#  the map, maybe they would find more motivation and put more effort. 
#  We could provide an easily accessible file 
#  or **ranking of most contributing users** to encourage them and maybe even somehow reward them for their effort.
#  However maybe some of them would take it as a competetive challange instead of volontary contribution.
# 

# A great idea would be also consult all the input to the data with the GoogleMaps which are certainly a verified source of informaiton. On the other hand it shoudl be a different device than Google itself, so let's hope to invent new ideas.

# ## Suggestions for improving and analyzing the dataset:
# 
# A big benefit would give a uniform street types if it is used for a business who prints street addresses from my database. Let's imagine a simple street type system in which we don't need to put a lot of effort in introducing it to a database and also the printed output would be clean and understandable for users.
# 
# During my cleaning I haven't predicted many little details like for example: "R." shortcut for Rua - just adding this little dot could have clenaed my data deeper.
# Another idea would be analyzing the coffee shops in Lisbon. The beautiful city is one of the best providers of coffee for only 0.5€ - 0.75€ cents. I think it would be very interesting to know how many coffee shops are there and which zone of the city has more cafes. I would have done if I had the idea before and could get some other dataset of coffee shopes to compare or check the validity of the input.
# Also the postcodes were not so messy I as expected, could have chosen another attribute for cleaning.
# 
# 

# The new popular game PokemonGo is also a useful data provider. Players have a lot of opportunities to discover cities and routes while simply catching pokemons. More users, more data for OSM, but let's be responsible and give a true input.
# Players could be mapping more attributes like parks or monuments or areas where sometimes it's difficult to get by car, but could also give wrong informaion for fun or simply lack of motivation, what can happpen to playing kids.
# Lisbon is still incomplete, let's hope that newest technology will make it full soon enough.

# The other aspect in which I see *a room for improvement* in this data set are highways. As we can see there are 27160 highways in Lisbon. Which I think is too many. 
# The contributors mixed the highway with other ways/routes.
# For example, we can find even **bus_stop** or turning circle. 
# We could find a way to specify more the area of input for users.
# 

# In[49]:

cur.execute('SELECT * FROM nodes_tags WHERE key="highway" limit 5')
all_rows = cur.fetchall()
pprint(all_rows)


# Honestly I was expecting more errors and misspelling in the dataset, if I knew before that it's so well done I could have provide a bigger changes in the streetname, like big letters and some gramma correction.
# 

# Maybe giving more specific requierements regarding their input would improve the quality of the maps.
# However, it can be dismotivating if the rules are too strict!

# ### Conclusions
# 
# Honestly, I expected this data to be more complex and less clean than it actually is.
# Maybe Lisbon is just not soo big to make errors while entering the info.
# I expected also that the usres would be more involved, but only a few of them really did a lot, beside of *_Josef K_*,
# who really put a heart into it.

# In[ ]:



