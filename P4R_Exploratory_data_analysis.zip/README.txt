REferences:

Websites which I used in order to complete this project:

https://www.r-bloggers.com/how-to-identify-risky-bank-loans-using-c-50-decision-trees/?utm_source=feedburner&utm_medium=email&utm_campaign=Feed%3A+RBloggers+%28R+bloggers%29
https://www.r-bloggers.com/heatmaply-an-r-package-for-creating-interactive-cluster-heatmaps-for-online-publishing/amp/
https://www.r-bloggers.com/how-to-make-a-global-map-in-r-step-by-step/amp/
http://www.sthda.com/english/wiki/colors-in-r
https://cran.r-project.org/doc/contrib/Komsta-Wprowadzenie.pdf
http://kgohz.sggw.pl/wp-content/uploads/2015/10/ANOVA-przypomnienie-i-regresja-wielokrotna.pdf
http://r4ds.had.co.nz/data-visualisation.html
https://s3.amazonaws.com/content.udacity-data.com/courses/ud651/diamondsExample_2016-05.html
https://pl.khanacademy.org/math/probability/data-distributions-a1/box--whisker-plots-a1/v/interpreting-box-plots
https://public.tableau.com/profile/marzena5080#!/vizhome/MalaCaty1/Story2?publish=yes
https://discussions.udacity.com/search?q=duplicate%20la
https://discussions.udacity.com/t/exploratory-data-analysis/249185/24



